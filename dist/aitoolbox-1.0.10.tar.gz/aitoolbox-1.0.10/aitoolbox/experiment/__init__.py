from aitoolbox.experiment.result_package.basic_packages import (
    BinaryClassificationResultPackage, ClassificationResultPackage, RegressionResultPackage)
